SSD � Lab 5 � Protecting against XSS

Note: You can run this lab on windows or Ubnutu VM forthis lab. You may have to install Intellij Idea enterprise trial edition and download the zap tool. 

1. Open the attached my-app Java Maven project in IntelliJ idea or any other IDE that supports Maven. Alternatively, you can build it using the Maven command line tool (if there're build errors, right click and select Maven->Reload project).

2. Build and deploy the .war file tomcat and run the application (same as the previous lab). 

3. Run the OWASP Zed Attack Proxy (ZAP) (https://owasp.org/www-project-zap/) and see whether it detects the XSS vulnerability. 

4. Fix the vulnerability using the OWASP Encoder (https://www.owasp.org/index.php/OWASP_Java_Encoder_Project). You may have to update the pom.xml file with Encoder dependency ((https://mvnrepository.com/artifact/org.owasp.encoder/encoder/1.2) and import the Encode class in the welcome.jsp page. Use the appropriate API function to do the encoding (https://owasp.github.io/owasp-java-encoder/encoder/apidocs/index.html?index-all.html).

Note: You may use the Encode class from the jsp code by directly importing the Encode class to the jsp page using the following page directive.

<%@ page import="org.owasp.encoder.Encode" %>


5. Now run the ZAP tool again to see whether the vulnerability is fixed.

6. Export the ZAP reports as html, both before and after fixing the vulnerability and archive the reports to a zip file. Archive the updated project to the same zip file. Rename the zip file to your registration no and upload to the courseweb link.

